const PL = require("plugins/hideplugins.py")

     run="const.PL"

#bad word kick
#grouplink kick
#text image
#more powerful item 😁
#new text to imsge
#emoji to txt
#bad word kick out
#anti group link
#spam kick Added
#Group Crash Added
