<div align="center">
<h1>🍁  ❤ Whatsapp Bot By Ravindu Manoj ❤  🍁</h1>
</div>



🇱🇰 FORE QR SCAN 👇👇👇👇 QR කේතය ලබාගැනීමට පහත රූපය මත ටච් කරන්න

[![Run on Repl.it](resources/gif/qr-scan.gif?size=40)](https://replit.com/@RavinduManoj/Queen-Sew-QR-Code)
For Deploy 👇👇👇 බොට්ව සෑදීම සදහා පහත රූපය මත ටච් කරන්න

[![Deploy](resources/gif/IMG_20210724_012025.png?size=40)](https://bit.ly/2XrSqG1)


#

#
## repl.it මගින් qr කේතය ලබා ගැනීමට අපහසු නම්..
### termux qr කෝඩ් එක ලබාගැනීමට අවශ්‍ය මූලික පැකේජ් නොමැතින් නම් පහත කමාන්ඩ් ලබා දෙන්න
දැනටමත් මෙම පැකේජ ඇත්නම් අවශ්‍ය නැත
```
$ pkg upgrade && pkg update
$ pkg install npm && pkg install git
$ pkg install node
```
### termux or console  එකක් මගින් qr එක ලබා ගැනීමට පහත කමාන්ඩ් යොදන්න
```
$ git clone https://github.com/Sew01RaviduManoj01KingAndQueen/sew.git
$ cd sew
$ npm i
$ node qr.js
```

## 🇱🇰 RAVINDU MANOJ 🇱🇰  
### SEW BOT FOR YOUR HELP😇

<div align="center">
<img src="https://github.com/Sew01RaviduManoj01KingAndQueen/imagehosting/blob/00aa7f2685f0114a2111f57149d8f0a27b2481c9/VID-20210724-WA0003.gif" />
  </div>

- [RavinduManoj](https://github.com/RavinduManoj)
- [@RavinduManoj](https://t.me/RavinduManoj)


<div align="center">
  <img src="https://github.com/RavinduManoj/imagehosting/blob/e18b9131ed1b5ec87d58359781c2a9c1044df810/temp_user_profile1621662133773.jpeg" width="250" height="250">
  
  
  <h1>🍁  Whatsapp Bot By Ravindu Manoj  🍁</h1>
  <h1>🇱🇰🇱🇰🇱🇰🇱🇰🇱🇰🇱🇰🇱🇰🇱🇰🇱🇰🇱🇰🇱🇰🇱🇰</h1>
</div>
<p align="center">
    SewQueen project - Makes it easy and fun to use Whatsapp. Also first userbot for Whatsapp.
    <br>
        <a href="https://t.me/RavinduManoj">Telegram Number</a> |
        <a href="https://t.me/AsenaSupport">Telegram Group</a> |
        <a href="https://t.me/asenaremaster">New Support Group</a> |
        <a href="https://t.me/unofficialplugin">New Plugin Channel</a> |
    <br>
</p>

----
![Docker Pulls](https://img.shields.io/docker/pulls/fusuf/whatsasena?style=flat-square) ![Docker Image Size (latest by date)](https://img.shields.io/docker/image-size/fusuf/whatsasena?style=flat-square)

## 🇱🇰 🔎 What is SewQueen?
**SewQueen,** is a WhatsApp helper bot written by [Ravindu Manoj](https://github.com/RavinduManoj). Does not log into your account It is written on WhatsApp Web API.

<h1>🇱🇰 Setup </h1>



##

### ⚒️ Setup Wiki - Kurulum [Full Guide - By Ravindu Manoj]
[![Setup - Raviya](https://github.com/RavinduManoj/imagehosting/blob/7d17c40df5099525556eb014b20a13eca4ac1176/20210628_090852.png?size=75 )](https://github.com/RavinduManoj/RaviyaBot/wiki)

##
<details>
    <summary>&#127942 <b>Warning</b></summary>
    
### 🇱🇰 ⚠️ Warning! 
```
Due to Userbot; Your WhatsApp account may be banned.
This is an open source project, you are responsible for everything you do. 
Absolutely, SewQueen executives do not accept responsibility.
By establishing the SewQueen, you are deemed to have accepted these responsibilities.
```

<div align="center">
<img src="https://github.com/Sew01RaviduManoj01KingAndQueen/imagehosting/blob/00aa7f2685f0114a2111f57149d8f0a27b2481c9/VID-20210724-WA0003.gif" />
  </div>p
</details>

##🇱🇰 Developer 🍁

[![RAVINDU MANOJ](https://bit.ly/3AyW139)](https://github.com/Sew01RaviduManoj01KingAndQueen/Sew01RaviduManoj01KingAndQueen#Readme.md)

## Thanks To
- [@adiwajshing](https://github.com/adiwajshing) for coded [Baileys](https://github.com/adiwajshing/Baileys) 

## License
This project is protected by `GNU General Public Licence v3.0` license.

### Disclaimer
`WhatsApp` name, its variations and the logo are registered trademarks of Facebook. We have nothing to do with the registered trademark

<div align="center">
  <img src="https://github.com/RavinduManoj/imagehosting/blob/7d17c40df5099525556eb014b20a13eca4ac1176/IMG_20210628_090553.jpg" width="250" height="250">
  <h1>🍁  Whatsapp Bot By Ravindu Manoj  🍁</h1>
  <h1>🇱🇰🇱🇰🇱🇰🇱🇰🇱🇰🇱🇰🇱🇰🇱🇰🇱🇰🇱🇰🇱🇰🇱🇰</h1>
</div>

<div align="center">
<img src="https://github.com/Sew01RaviduManoj01KingAndQueen/imagehosting/blob/00aa7f2685f0114a2111f57149d8f0a27b2481c9/VID-20210724-WA0003.gif" />
  </div>
  
<details>
    <summary>&#127942 <b>SewQueen Features</b></summary>
    
## 🇱🇰 SewQueen Features

| All Features 📢|Available ☑️|Version 🔎|
| ------------- | ------------ | ---------- |
| Admin Commands|✅|1.0|
| AFK|✅|1.2|
| APKMOD|✅|1.2|
| AI Scanner|✅|1.1|
| Add & Kick User|✅|1.0|
| Carbon.sh Plugin|✅|1.4|
| Deep AI APIs|✅|1.0
| Ban & Unban User|✅|1.0|
| FFMPEG Support|✅|1.6|
| Filter Support|✅|1.2|
| Greetings Support|✅|1.2|
| Group Link Generator|✅|1.0|
| Heroku Plugin|✅|1.5|
| Jid Scraper|✅|1.0|
| Location Plugin|✅|1.0|
| Lydia|✅|1.2|
| Music Downloader|✅|1.2|
| Meme Maker|✅|1.0|
| Mute & Unmute Chat|✅|1.3|
| Nekobin Plugin|✅|1.0|
| OCR Plugin|✅|1.2|
| Plugin Support|✅|1.0|
| Pre-Trained Effects|✅|3.2|
| Promote & Demote User|✅|1.1|
| Remove BG Plugin|✅|1.0|
| Youtube Downloader|✅|1.2|
| Scam Actions|✅|1.3|
| Scrapers|✅|1.5|
| Spammer|✅|1.4|
| Speedtest|🛠️|1.6|
| Sticker Maker|✅|1.0|
| Tagall|✅|1.0|
| Google TTS|✅|1.6|
| Unvoice|✅|1.3|
| Web Screenshot Plugin|✅|1.5|
| Wallpaper Plugin|✅|1.4|

<div align="center">
<img src="https://github.com/Sew01RaviduManoj01KingAndQueen/imagehosting/blob/00aa7f2685f0114a2111f57149d8f0a27b2481c9/VID-20210724-WA0003.gif" />
  </div>

| Command 💻 |Description ℹ️|
| ---------- | -------------------- |
| .raviya| Shows all existing commands.|
| .alive| Checks if the bot is running.|
| .ban| Kick the user from the group.|
| .afk| It makes you AFK. Sends the afk message when you receive a private message or tag.|
| .term| Allows the ability to execute commands on the server shell.|
| .block| It blocks the user from WhatsApp.|
| .unblock| It unblocks the user from WhatsApp.|
| .add| Adds people to the group.|
| .plugin| Shows the plugins you have installed.|
| .install| It installs plugins.|
| .remove| It delete plugins.|
| .xmedia| It shows preset effects that you can apply to photo, video, and sound.|
| .unvoice| Sends any sound as a voice message.|
| .scam| It does fake actions.|
| .carbon| Converts the text to the code picture.|
| .promote| Makes someone in the group admin.|
| .demote| It takes admin from someone in the group.|
| .mute| Close the chat.|
| .unmute| Open the chat.|
| .invite| Sends the link to the group.|
| .mp4audio| Converts video to sound.|
| .imagesticker| Converts image sticker to photo.|
| .ffmpeg| It applies the desired ffmpeg filter to the video.|
| .filter| Adds a filter. It is active when someone writes the filter.|
| .stop| Stops the filter.|
| .ss| Takes a screenshot of the page in the given link.|
| .welcome| Sends a message to those who enter the group.|
| .goodbye| Sends a message to those leaving the group.|
| .restart| Restarts the bot.|
| .shutdown| Shutdown the bot.|
| .dyno| Displays your remaining dyno hours.|
| .getvar| Shows the config var status.|
| .setvar| Sets the config var.|
| .delvar| Remove the config var.|
| .locate| It sends your location quickly.|
| .addlydia| It activates the artificial intelligence chat.|
| .rmlydia| Stops Artificial intelligence chatting.|
| .meme| It makes a meme to the photo.|
| .neko| It saves the message you answered to Nekobin.|
| .ocr| Reads the text in the photograph and translates it into text.|
| .kickme| It will kick you out of the group you are.|
| .pp| It makes the profile photo which you reply to.|
| .jid| It shows the jid address of any person.|
| .removebg| Removes the background of the photo you replied to.|
| .trt| Translates between languages.|
| .tts| Converts text to voice message.|
| .currency| Converts currencies.|
| .song| It downloads the song you wrote.|
| .yt| Search on Youtube.|
| .video| Downloads video from Youtube.|
| .wiki| Searches on Wikipedia.|
| .img| It downloads 5 photos from the word you wrote.|
| .spam| It will send your typed text as spam until you stop it.|
| .killspam| It stops spam.|
| .sticker| It makes a photo or video to sticker.|
| .sysd| Shows system properties.|
| .tagall| Tags everyone in the group.|
| .update| Checks for updates.|
| .update now| Update the bot.|
| .weather| Shows the weather of the city you are typing in.|
| .ping| Ping meter!|
| .speedtest| Makes speed test.|
| .deepai| Provides a list of AI tools that use deep learning with Deep AI artificial intelligence.|
| .wallpaper| Sends random high resolution wallpaper.|

<div align="center">
<img src="https://github.com/Sew01RaviduManoj01KingAndQueen/imagehosting/blob/00aa7f2685f0114a2111f57149d8f0a27b2481c9/VID-20210724-WA0003.gif" />
  </div>

### XMedia Plugin Commands 🛠️
| Command 💻 | Description ℹ️|
| ---------- | -------------------- |
| .mp4enhance| It improves the quality of the video.
| .x2mp4| It reduces the quality of the video by 2 times.
| .x4mp4| It reduces the quality of the video by 4 times.
| .mp4reverse| Plays the video in reverse.
| .mp4blur| Blurs the video background.
| .mp4vintage| Applies a vintage effect to the video.
| .mp4bw| Applies a monochrome effect to the video.
| .mp4edge| It calculates the depth of the viden and applies the neon edge effect accordingly.
| .mp4image| Converts photo to 5 seconds video.
| .gif| It makes the video gif.
| .agif| Makes the video an audio gif.
| .spectrum| It converts the spectrum of sound into video.
| .avec| Converts the frequency range of the sound to 3D video.
| .waves| It converts the wavelengths of sound into video.
| .frequency| Converts the frequency of the sound to video.
| .volumeaudio| Converts the decibel value of sound to video.
| .cqtaudio| Converts the cqt value of audio to video.
| .mp3eq| Adjusts the sound to a crystal clear level.
| .mp3low| It makes the sound deep and slow.
| .mp3pitch| It refines and accelerates the sound.
| .mp3crusher| It distorts the sound, makes it ridiculous.
| .mp3reverse| Plays the sound in reverse.
| .x2mp3| It speeds up the sound 2 times.
| .mp3volume| It increases the sound level 6 times.
| .bwimage| Makes the photo black and white.
| .vintageimage| Applies a vintage effect to the photo.
| .edgeimage| It calculates the depth of the photo and appropriately applies an edge effect.
| .enhanceimage| It improves the quality of the photo.
| .grenimage| Applies a grain effect to the photo.
| .blurimage| Blurs the background of the photo.

### Scam Commands 🛠️
| Command 💻 | Description ℹ️|
| ---------- | -------------------- |
| .scam typing| It shows you typing for 5 minutes.|
| .scam recording| It shows you as recording for 5 minutes.|
| .scam online| It shows you online for 5 minutes.|
| .scam stop| Stops fake actions.|

<div align="center">
<img src="https://github.com/Sew01RaviduManoj01KingAndQueen/imagehosting/blob/00aa7f2685f0114a2111f57149d8f0a27b2481c9/VID-20210724-WA0003.gif" />
  </div>


### Deep AI Commands 🛠️
| Command 💻 | Discretion ℹ️|
| ---------- | -------------------- |
| .colorai| Colorizes the photo.|
| .superai| It improves the image quality.|
| .dreamai| Applies a deepdream effect to the photo.|
| .waifuai| It mixes the color palettes of photo.|
| .neuraltalkai| Explain the incident in the photo.|
| .toonai| Applies a cartoon effect to the face of image.|
| .ttiai| Generates nonexistent photos from your sentence.|
| .moodai| It determines your mood from the sentence you write.|
| .textai| Creates a virtual story from your sentence.|
| .nudityai| Shows the NSFW value of the photo between 1 and 0.|
| .ganstyle| Combines pictures with the image link in Config Vars with the help of artificial intelligence.|

<div align="center">
<img src="https://github.com/Sew01RaviduManoj01KingAndQueen/imagehosting/blob/00aa7f2685f0114a2111f57149d8f0a27b2481c9/VID-20210724-WA0003.gif" />
  </div>
</details>
